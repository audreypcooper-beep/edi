'use strict';

const jwt = require('jsonwebtoken');
const jwksClient = require('jwks-rsa');

const { region } = require('../config/aws');

// Cache the JWKS client per user pool to avoid re-fetching on every request.
const clientCache = new Map();

/**
 * Returns a jwks-rsa client for the given Cognito user pool.
 * Clients are cached so the JWKS endpoint is not hammered on every request.
 */
function getJwksClient(userPoolId) {
  if (clientCache.has(userPoolId)) {
    return clientCache.get(userPoolId);
  }

  const client = jwksClient({
    jwksUri: `https://cognito-idp.${region}.amazonaws.com/${userPoolId}/.well-known/jwks.json`,
    cache: true,
    cacheMaxEntries: 10,
    cacheMaxAge: 10 * 60 * 1000, // 10 minutes
    rateLimit: true,
    jwksRequestsPerMinute: 10,
  });

  clientCache.set(userPoolId, client);
  return client;
}

/**
 * Retrieves the signing key from the JWKS endpoint that matches the `kid`
 * found in the JWT header.
 */
function getSigningKey(client, kid) {
  return new Promise((resolve, reject) => {
    client.getSigningKey(kid, (err, key) => {
      if (err) return reject(err);
      resolve(key.getPublicKey());
    });
  });
}

/**
 * Express middleware — validates Cognito-issued JWTs.
 *
 * Expected header: Authorization: Bearer <id_token>
 *
 * On success, attaches req.user = { sub, email, given_name, family_name, ... }
 * On failure, responds immediately with HTTP 401.
 */
async function auth(req, res, next) {
  try {
    const authHeader = req.headers['authorization'] || req.headers['Authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Missing or malformed Authorization header.',
        code: 'MISSING_TOKEN',
      });
    }

    const token = authHeader.slice(7); // strip "Bearer "

    // Decode without verification first so we can extract `kid` to look up
    // the correct public key from the JWKS endpoint.
    const decoded = jwt.decode(token, { complete: true });

    if (!decoded || !decoded.header || !decoded.header.kid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid token structure.',
        code: 'INVALID_TOKEN',
      });
    }

    const userPoolId = process.env.COGNITO_USER_POOL_ID;
    if (!userPoolId) {
      // Misconfiguration — do not leak details to the client
      console.error('[auth] COGNITO_USER_POOL_ID is not set');
      return res.status(500).json({
        success: false,
        message: 'Server configuration error.',
        code: 'SERVER_ERROR',
      });
    }

    const client = getJwksClient(userPoolId);
    const signingKey = await getSigningKey(client, decoded.header.kid);

    // Verify signature, expiry, and issuer.
    const payload = jwt.verify(token, signingKey, {
      algorithms: ['RS256'],
      issuer: `https://cognito-idp.${region}.amazonaws.com/${userPoolId}`,
    });

    // Cognito id tokens carry `token_use: "id"`.
    // Access tokens carry `token_use: "access"`.
    // We accept both but prefer id tokens for the user profile fields.
    req.user = {
      sub: payload.sub,
      email: payload.email || payload.username,
      given_name: payload.given_name || '',
      family_name: payload.family_name || '',
      orgName: payload['custom:orgName'] || '',
      npi: payload['custom:npi'] || '',
      taxId: payload['custom:taxId'] || '',
      accountType: payload['custom:accountType'] || '',
    };

    next();
  } catch (err) {
    if (err instanceof jwt.TokenExpiredError) {
      return res.status(401).json({
        success: false,
        message: 'Token has expired.',
        code: 'TOKEN_EXPIRED',
      });
    }

    if (err instanceof jwt.JsonWebTokenError) {
      return res.status(401).json({
        success: false,
        message: 'Invalid token.',
        code: 'INVALID_TOKEN',
      });
    }

    // JWKS fetch or other unexpected errors
    console.error('[auth] Unexpected error verifying token:', err);
    return res.status(401).json({
      success: false,
      message: 'Token verification failed.',
      code: 'TOKEN_VERIFICATION_FAILED',
    });
  }
}

module.exports = auth;
