'use strict';

const { Router } = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');

const auth       = require('../middleware/auth');
const dynamoSvc  = require('../services/dynamodb');
const sqsSvc     = require('../services/sqs');
const s3Svc      = require('../services/s3');
const sesSvc     = require('../services/ses');
const { generate270, generate837P } = require('../utils/ediGenerator');
const { generateReferenceId } = require('../utils/referenceId');
const { TABLES, EDI_STATUS } = require('../config/constants');

const router = Router();
router.use(auth);

function validateReq(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({ success: false, message: errors.array()[0].msg, errors: errors.array() });
    return false;
  }
  return true;
}

// ── POST /api/edi/270 — Submit Eligibility Inquiry ───────────────────────
router.post(
  '/270',
  [
    body('payerId').notEmpty().withMessage('Payer ID is required'),
    body('memberId').notEmpty().withMessage('Member ID is required'),
    body('providerNpi').isLength({ min: 10, max: 10 }).withMessage('Valid 10-digit NPI required'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const {
        payerId, payerName, memberId, memberFirstName, memberLastName,
        memberDob, memberGender, groupNumber, providerNpi, providerName,
        serviceTypeCode, serviceDate,
      } = req.body;

      const referenceId = generateReferenceId();
      const transactionId = uuidv4();

      const rawEdi = generate270({
        payerId,
        receiverId: payerId,
        referenceId,
        providerNpi,
        providerName: providerName || 'CLEARPATH MEDICAL GROUP',
        memberId,
        memberFirstName,
        memberLastName,
        memberDob,
        memberGender,
        groupNumber,
        serviceTypeCode: serviceTypeCode || '30',
        serviceDate,
      });

      const transaction = {
        userId: req.user.sub,
        transactionId,
        referenceId,
        transactionType: '270',
        payerId,
        payerName: payerName || payerId,
        memberId,
        memberFirstName: memberFirstName || '',
        memberLastName: memberLastName || '',
        memberDob: memberDob || '',
        memberGender: memberGender || '',
        groupNumber: groupNumber || '',
        providerNpi,
        serviceTypeCode: serviceTypeCode || '30',
        serviceDate: serviceDate || '',
        status: EDI_STATUS.PENDING,
        rawEdi,
        submittedBy: req.user.email,
      };

      await dynamoSvc.putItem(TABLES.TRANSACTIONS, transaction);

      // Queue for processing by backend worker
      try {
        await sqsSvc.sendMessage({
          queueUrl: process.env.SQS_EDI_PROCESSING_QUEUE_URL,
          body: JSON.stringify({ transactionId, referenceId, type: '270', userId: req.user.sub }),
          messageGroupId: req.user.sub,
          deduplicationId: transactionId,
        });
      } catch (sqsErr) {
        console.warn('[edi/270] SQS enqueue failed:', sqsErr.message);
      }

      // Store raw EDI on S3
      try {
        await s3Svc.uploadFile({
          bucket: process.env.S3_BUCKET,
          key: `edi/270/${req.user.sub}/${referenceId}.edi`,
          body: rawEdi,
          contentType: 'text/plain',
        });
      } catch (s3Err) {
        console.warn('[edi/270] S3 upload failed:', s3Err.message);
      }

      // Send confirmation email
      try {
        await sesSvc.sendEdi270ConfirmationEmail({
          to: req.user.email,
          referenceId,
          payerName: payerName || payerId,
          memberName: `${memberFirstName || ''} ${memberLastName || ''}`.trim(),
          memberId,
        });
      } catch (emailErr) {
        console.warn('[edi/270] Confirmation email failed:', emailErr.message);
      }

      res.status(201).json({
        success: true,
        message: 'EDI 270 submitted successfully. Your client team will route this to the payer.',
        referenceId,
        transactionId,
        status: EDI_STATUS.PENDING,
        rawEdi,
      });
    } catch (err) {
      next(err);
    }
  },
);

// ── GET /api/edi/transactions — List user's EDI transactions ─────────────
router.get('/transactions', async (req, res, next) => {
  try {
    const { limit = '50', lastKey, type } = req.query;
    const options = {
      expressionAttributeValues: { ':uid': req.user.sub },
      scanIndexForward: false,
      limit: Math.min(parseInt(limit, 10) || 50, 200),
    };
    if (lastKey) {
      try { options.lastKey = JSON.parse(decodeURIComponent(lastKey)); } catch (_) {}
    }
    if (type) {
      options.filterExpression = 'transactionType = :type';
      options.expressionAttributeValues[':type'] = type;
    }

    const { items, lastKey: nextKey } = await dynamoSvc.queryItems(
      TABLES.TRANSACTIONS,
      'userId = :uid',
      options,
    );

    res.json({
      success: true,
      transactions: items,
      nextKey: nextKey ? encodeURIComponent(JSON.stringify(nextKey)) : null,
    });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/edi/transactions/:id — Get single transaction ───────────────
router.get('/transactions/:id', async (req, res, next) => {
  try {
    const transaction = await dynamoSvc.getItem(TABLES.TRANSACTIONS, {
      userId: req.user.sub,
      transactionId: req.params.id,
    });
    if (!transaction) {
      return res.status(404).json({ success: false, message: 'Transaction not found.' });
    }
    res.json({ success: true, transaction });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/edi/transactions/:id/download — Download raw EDI ────────────
router.get('/transactions/:id/download', async (req, res, next) => {
  try {
    const transaction = await dynamoSvc.getItem(TABLES.TRANSACTIONS, {
      userId: req.user.sub,
      transactionId: req.params.id,
    });
    if (!transaction) {
      return res.status(404).json({ success: false, message: 'Transaction not found.' });
    }
    if (transaction.rawEdi) {
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="${transaction.referenceId}.edi"`);
      return res.send(transaction.rawEdi);
    }
    // Try S3 signed URL
    const url = await s3Svc.getSignedDownloadUrl({
      bucket: process.env.S3_BUCKET,
      key: `edi/${transaction.transactionType}/${req.user.sub}/${transaction.referenceId}.edi`,
      expiresIn: 300,
    });
    res.json({ success: true, url });
  } catch (err) {
    next(err);
  }
});

// ── POST /api/edi/setup — Submit EDI API Setup Enrollment Request ─────────
router.post(
  '/setup',
  [
    body('vendorName').notEmpty().withMessage('Vendor/company name is required'),
    body('contactEmail').isEmail().withMessage('Valid contact email is required'),
    body('payerName').notEmpty().withMessage('Payer name is required'),
    body('payerId').notEmpty().withMessage('Payer ID is required'),
    body('transactionTypes').isArray({ min: 1 }).withMessage('At least one transaction type is required'),
    body('techContactEmail').isEmail().withMessage('Valid technical contact email is required'),
    body('authName').notEmpty().withMessage('Authorized signatory name is required'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;

      const requestId  = uuidv4();
      const referenceId = generateReferenceId('SET');

      const setupRequest = {
        userId:             req.user.sub,
        requestId,
        referenceId,
        submittedBy:        req.user.email,
        status:             'PENDING_ADMIN_REVIEW',
        createdAt:          new Date().toISOString(),
        // Third party
        vendorName:         req.body.vendorName,
        vendorType:         req.body.vendorType        || '',
        contactName:        req.body.contactName       || '',
        contactEmail:       req.body.contactEmail,
        contactPhone:       req.body.contactPhone      || '',
        vendorNpi:          req.body.vendorNpi         || '',
        vendorTaxId:        req.body.vendorTaxId       || '',
        // Payer
        payerName:          req.body.payerName,
        payerId:            req.body.payerId,
        payerType:          req.body.payerType         || '',
        environment:        req.body.environment       || 'Production',
        transactionTypes:   req.body.transactionTypes,
        // Technical
        clearinghouse:      req.body.clearinghouse     || '',
        submitterId:        req.body.submitterId       || '',
        isaSenderId:        req.body.isaSenderId       || '',
        techContactName:    req.body.techContactName   || '',
        techContactEmail:   req.body.techContactEmail,
        techPhone:          req.body.techPhone         || '',
        goLiveDate:         req.body.goLiveDate        || '',
        // Authorization
        authName:           req.body.authName,
        authTitle:          req.body.authTitle         || '',
        authDate:           req.body.authDate          || new Date().toISOString().slice(0, 10),
        notes:              req.body.notes             || '',
      };

      await dynamoSvc.putItem(TABLES.TRANSACTIONS, { ...setupRequest, transactionType: 'SETUP' });

      // Notify EDI admin
      const adminEmail = process.env.EDI_ADMIN_EMAIL || process.env.SES_FROM_EMAIL;
      if (adminEmail) {
        try {
          await sesSvc.sendEmail({
            to: adminEmail,
            subject: `[ClearPath] New EDI Setup Request — ${setupRequest.vendorName} / ${setupRequest.payerName}`,
            htmlBody: buildAdminNotificationEmail(setupRequest),
            textBody: `New EDI setup request submitted.\n\nRef: ${referenceId}\nVendor: ${setupRequest.vendorName}\nPayer: ${setupRequest.payerName} (${setupRequest.payerId})\nTransactions: ${setupRequest.transactionTypes.join(', ')}\nSubmitted by: ${setupRequest.submittedBy}\n\nPlease log in to the ClearPath portal to review and approve this request.`,
          });
        } catch (emailErr) {
          console.warn('[edi/setup] Admin notification email failed:', emailErr.message);
        }
      }

      // Confirm to submitter
      try {
        await sesSvc.sendEmail({
          to: req.user.email,
          subject: `[ClearPath] EDI Setup Request Received — ${referenceId}`,
          htmlBody: `<p>Your EDI setup request for <strong>${setupRequest.vendorName}</strong> with <strong>${setupRequest.payerName}</strong> has been received.</p><p>Reference ID: <strong>${referenceId}</strong></p><p>Your EDI Administrator will review this request and route it to the payer's EDI enrollment team. You will be notified when the status changes.</p>`,
          textBody: `Your EDI setup request (${referenceId}) for ${setupRequest.vendorName} / ${setupRequest.payerName} has been received and is pending administrator review.`,
        });
      } catch (emailErr) {
        console.warn('[edi/setup] Submitter confirmation email failed:', emailErr.message);
      }

      res.status(201).json({
        success:     true,
        message:     'EDI setup request submitted. Your EDI Administrator has been notified and will review and route this to the payer.',
        referenceId,
        requestId,
        status:      'PENDING_ADMIN_REVIEW',
      });
    } catch (err) {
      next(err);
    }
  },
);

// ── GET /api/edi/setup — List setup requests for this user ────────────────
router.get('/setup', async (req, res, next) => {
  try {
    const { items } = await dynamoSvc.queryItems(
      TABLES.TRANSACTIONS,
      'userId = :uid',
      {
        expressionAttributeValues: { ':uid': req.user.sub, ':type': 'SETUP' },
        filterExpression: 'transactionType = :type',
        scanIndexForward: false,
        limit: 100,
      },
    );
    res.json({ success: true, requests: items });
  } catch (err) {
    next(err);
  }
});

// ── PUT /api/edi/setup/:id/approve — EDI Admin approves and sends to payer
router.put('/setup/:id/approve', async (req, res, next) => {
  try {
    const item = await dynamoSvc.getItem(TABLES.TRANSACTIONS, {
      userId: req.user.sub,
      transactionId: req.params.id,
    });
    if (!item) return res.status(404).json({ success: false, message: 'Setup request not found.' });

    const adminNotes = req.body.adminNotes || '';
    const payerEnrollmentEmail = req.body.payerEnrollmentEmail || '';

    await dynamoSvc.updateItem(
      TABLES.TRANSACTIONS,
      { userId: req.user.sub, transactionId: req.params.id },
      'SET #st = :s, adminNotes = :n, approvedAt = :t, approvedBy = :by',
      {
        expressionAttributeNames: { '#st': 'status' },
        expressionAttributeValues: {
          ':s':  'ADMIN_APPROVED',
          ':n':  adminNotes,
          ':t':  new Date().toISOString(),
          ':by': req.user.email,
        },
      },
    );

    // Send enrollment packet to payer if email provided
    if (payerEnrollmentEmail) {
      try {
        await sesSvc.sendEmail({
          to: payerEnrollmentEmail,
          subject: `EDI Enrollment Request — ${item.vendorName} — ${item.transactionTypes.join(', ')}`,
          htmlBody: buildPayerEnrollmentEmail(item, adminNotes),
          textBody: `EDI enrollment request for ${item.vendorName}.\n\nPayer: ${item.payerName} (${item.payerId})\nTransactions: ${item.transactionTypes.join(', ')}\nContact: ${item.contactName} <${item.contactEmail}>\nNPI: ${item.vendorNpi || 'N/A'}\nTax ID: ${item.vendorTaxId || 'N/A'}\nSubmitter ID: ${item.submitterId || 'Pending'}\nClearinghouse: ${item.clearinghouse || 'N/A'}\nAuthorized by: ${item.authName}\n\nAdmin notes: ${adminNotes}`,
        });
      } catch (emailErr) {
        console.warn('[edi/setup/approve] Payer email failed:', emailErr.message);
      }
      await dynamoSvc.updateItem(
        TABLES.TRANSACTIONS,
        { userId: req.user.sub, transactionId: req.params.id },
        'SET #st = :s, sentToPayerAt = :t',
        {
          expressionAttributeNames: { '#st': 'status' },
          expressionAttributeValues: { ':s': 'SENT_TO_PAYER', ':t': new Date().toISOString() },
        },
      );
    }

    res.json({ success: true, message: 'Setup request approved.' + (payerEnrollmentEmail ? ' Enrollment sent to payer.' : '') });
  } catch (err) {
    next(err);
  }
});

// ── Email builders ────────────────────────────────────────────────────────

function buildAdminNotificationEmail(r) {
  return `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
      <div style="background:#1a3a5c;color:#fff;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="margin:0;font-size:18px">New EDI Setup Request</h2>
        <p style="margin:4px 0 0;opacity:.8;font-size:13px">Ref: ${r.referenceId}</p>
      </div>
      <div style="background:#f8fafc;padding:24px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px">
        <table style="width:100%;border-collapse:collapse;font-size:13px">
          <tr><td style="padding:6px 0;color:#64748b;width:160px">Vendor / Company</td><td style="padding:6px 0;font-weight:600">${r.vendorName}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Vendor Type</td><td style="padding:6px 0">${r.vendorType || '—'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Contact</td><td style="padding:6px 0">${r.contactName} &lt;${r.contactEmail}&gt;</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">NPI</td><td style="padding:6px 0">${r.vendorNpi || '—'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Tax ID</td><td style="padding:6px 0">${r.vendorTaxId || '—'}</td></tr>
          <tr><td colspan="2" style="padding:12px 0 4px;font-weight:700;color:#1a3a5c">Payer</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Payer</td><td style="padding:6px 0">${r.payerName} (${r.payerId})</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Environment</td><td style="padding:6px 0">${r.environment}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Transactions</td><td style="padding:6px 0"><strong>${r.transactionTypes.join(', ')}</strong></td></tr>
          <tr><td colspan="2" style="padding:12px 0 4px;font-weight:700;color:#1a3a5c">Technical</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Clearinghouse</td><td style="padding:6px 0">${r.clearinghouse || '—'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Submitter ID</td><td style="padding:6px 0">${r.submitterId || 'Pending assignment'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">ISA Sender ID</td><td style="padding:6px 0">${r.isaSenderId || '—'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Tech Contact</td><td style="padding:6px 0">${r.techContactName} &lt;${r.techContactEmail}&gt;</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Go-Live Date</td><td style="padding:6px 0">${r.goLiveDate || '—'}</td></tr>
          <tr><td colspan="2" style="padding:12px 0 4px;font-weight:700;color:#1a3a5c">Authorization</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Signed by</td><td style="padding:6px 0">${r.authName}${r.authTitle ? ', ' + r.authTitle : ''} on ${r.authDate}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Submitted by</td><td style="padding:6px 0">${r.submittedBy}</td></tr>
          ${r.notes ? `<tr><td style="padding:6px 0;color:#64748b">Notes</td><td style="padding:6px 0">${r.notes}</td></tr>` : ''}
        </table>
        <div style="margin-top:20px;padding:16px;background:#fff;border:1px solid #e2e8f0;border-radius:6px">
          <p style="margin:0 0 12px;font-size:13px">Please review this request and, once complete, use the ClearPath portal to approve and send the enrollment packet to the payer's EDI setup team.</p>
        </div>
      </div>
    </div>`;
}

function buildPayerEnrollmentEmail(r, adminNotes) {
  return `
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
      <div style="background:#1a3a5c;color:#fff;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="margin:0;font-size:18px">EDI Trading Partner Enrollment Request</h2>
        <p style="margin:4px 0 0;opacity:.8;font-size:13px">Submitted via ClearPath EDI Portal</p>
      </div>
      <div style="background:#f8fafc;padding:24px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px;font-size:13px">
        <p>Please process the following EDI trading partner enrollment for:</p>
        <table style="width:100%;border-collapse:collapse">
          <tr><td style="padding:6px 0;color:#64748b;width:160px">Organization</td><td style="padding:6px 0;font-weight:600">${r.vendorName}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">NPI</td><td style="padding:6px 0">${r.vendorNpi || 'N/A'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Tax ID</td><td style="padding:6px 0">${r.vendorTaxId || 'N/A'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Contact</td><td style="padding:6px 0">${r.contactName} — ${r.contactEmail}${r.contactPhone ? ' / ' + r.contactPhone : ''}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Transactions</td><td style="padding:6px 0"><strong>${r.transactionTypes.join(', ')}</strong></td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Clearinghouse</td><td style="padding:6px 0">${r.clearinghouse || 'N/A'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Submitter ID</td><td style="padding:6px 0">${r.submitterId || 'Please assign'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">ISA Sender ID</td><td style="padding:6px 0">${r.isaSenderId || 'Please assign'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Tech Contact</td><td style="padding:6px 0">${r.techContactName} — ${r.techContactEmail}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Requested Go-Live</td><td style="padding:6px 0">${r.goLiveDate || 'ASAP'}</td></tr>
          <tr><td style="padding:6px 0;color:#64748b">Authorized By</td><td style="padding:6px 0">${r.authName}${r.authTitle ? ', ' + r.authTitle : ''}</td></tr>
          ${adminNotes ? `<tr><td style="padding:6px 0;color:#64748b">Admin Notes</td><td style="padding:6px 0">${adminNotes}</td></tr>` : ''}
        </table>
      </div>
    </div>`;
}

// ── GET /api/edi/stats — Dashboard stats ─────────────────────────────────
router.get('/stats', async (req, res, next) => {
  try {
    const { items } = await dynamoSvc.queryItems(
      TABLES.TRANSACTIONS,
      'userId = :uid',
      {
        expressionAttributeValues: { ':uid': req.user.sub },
        scanIndexForward: false,
        limit: 200,
      },
    );

    const stats = {
      total: items.length,
      pending: items.filter((t) => t.status === EDI_STATUS.PENDING).length,
      processing: items.filter((t) => t.status === EDI_STATUS.PROCESSING).length,
      sent: items.filter((t) => t.status === EDI_STATUS.SENT).length,
      responseReceived: items.filter((t) => t.status === EDI_STATUS.RESPONSE_RECEIVED).length,
      error: items.filter((t) => t.status === EDI_STATUS.ERROR).length,
      byType: items.reduce((acc, t) => {
        acc[t.transactionType] = (acc[t.transactionType] || 0) + 1;
        return acc;
      }, {}),
    };

    res.json({ success: true, stats, recentTransactions: items.slice(0, 10) });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
