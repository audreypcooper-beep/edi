'use strict';

const { Router } = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');

const cognitoSvc = require('../services/cognito');
const dynamoSvc  = require('../services/dynamodb');
const sesSvc     = require('../services/ses');
const { TABLES } = require('../config/constants');
const { createError } = require('../middleware/errorHandler');

const router = Router();

// ── Validation helper ─────────────────────────────────────────────────────
function validateReq(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({ success: false, message: errors.array()[0].msg, errors: errors.array() });
    return false;
  }
  return true;
}

// ── POST /api/auth/register ───────────────────────────────────────────────
router.post(
  '/register',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
      .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
      .matches(/[0-9]/).withMessage('Password must contain a number'),
    body('givenName').trim().notEmpty().withMessage('First name required'),
    body('familyName').trim().notEmpty().withMessage('Last name required'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const { email, password, givenName, familyName, orgName, npi, taxId, accountType } = req.body;

      const { userSub } = await cognitoSvc.signUp({
        email, password, givenName, familyName,
        orgName: orgName || '',
        npi: npi || '',
        taxId: taxId || '',
        accountType: accountType || 'PROVIDER',
      });

      // Store profile in DynamoDB
      await dynamoSvc.putItem(TABLES.USERS, {
        userId: userSub,
        email,
        givenName,
        familyName,
        orgName: orgName || '',
        npi: npi || '',
        taxId: taxId || '',
        accountType: accountType || 'PROVIDER',
        profileComplete: false,
        notificationsEmail: true,
        notificationsSms: false,
      });

      // Send welcome email
      try {
        await sesSvc.sendEmail({
          to: email,
          subject: 'Welcome to ClearPath EDI',
          html: `<p>Welcome, ${givenName}! Your ClearPath EDI account has been created. You can now log in and begin configuring your EDI transactions.</p>`,
          text: `Welcome, ${givenName}! Your ClearPath EDI account has been created.`,
        });
      } catch (emailErr) {
        // Non-fatal — log but don't fail registration
        console.warn('[auth/register] Welcome email failed:', emailErr.message);
      }

      res.status(201).json({ success: true, message: 'Account created successfully.', userId: userSub });
    } catch (err) {
      next(err);
    }
  },
);

// ── POST /api/auth/login ──────────────────────────────────────────────────
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password').notEmpty().withMessage('Password required'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const { email, password } = req.body;
      const tokens = await cognitoSvc.signIn({ email, password });
      res.json({ success: true, ...tokens });
    } catch (err) {
      next(err);
    }
  },
);

// ── POST /api/auth/logout ─────────────────────────────────────────────────
router.post('/logout', async (req, res, next) => {
  try {
    const { accessToken } = req.body;
    if (accessToken) await cognitoSvc.signOut({ accessToken });
    res.json({ success: true, message: 'Logged out.' });
  } catch (err) {
    next(err);
  }
});

// ── POST /api/auth/refresh ────────────────────────────────────────────────
router.post(
  '/refresh',
  [body('refreshToken').notEmpty().withMessage('refreshToken required')],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const tokens = await cognitoSvc.refreshToken({ refreshToken: req.body.refreshToken });
      res.json({ success: true, ...tokens });
    } catch (err) {
      next(err);
    }
  },
);

// ── POST /api/auth/forgot-password ───────────────────────────────────────
router.post(
  '/forgot-password',
  [body('email').isEmail().normalizeEmail().withMessage('Valid email required')],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      await cognitoSvc.forgotPassword({ email: req.body.email });
      // Always return success to prevent email enumeration
      res.json({ success: true, message: 'If this email exists, a reset code has been sent.' });
    } catch (err) {
      // Swallow UserNotFoundException for security
      if (err.name === 'UserNotFoundException') {
        return res.json({ success: true, message: 'If this email exists, a reset code has been sent.' });
      }
      next(err);
    }
  },
);

// ── POST /api/auth/confirm-password ──────────────────────────────────────
router.post(
  '/confirm-password',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('confirmationCode').notEmpty().withMessage('Confirmation code required'),
    body('newPassword').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const { email, confirmationCode, newPassword } = req.body;
      await cognitoSvc.confirmForgotPassword({ email, confirmationCode, newPassword });
      res.json({ success: true, message: 'Password reset successfully. You can now sign in.' });
    } catch (err) {
      next(err);
    }
  },
);

// ── POST /api/auth/change-password ───────────────────────────────────────
const authMiddleware = require('../middleware/auth');
router.post(
  '/change-password',
  authMiddleware,
  [
    body('previousPassword').notEmpty().withMessage('Current password required'),
    body('proposedPassword').isLength({ min: 8 }).withMessage('New password must be at least 8 characters'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const { previousPassword, proposedPassword } = req.body;
      const accessToken = req.headers.authorization.slice(7);
      await cognitoSvc.changePassword({ accessToken, previousPassword, proposedPassword });
      res.json({ success: true, message: 'Password changed successfully.' });
    } catch (err) {
      next(err);
    }
  },
);

module.exports = router;
