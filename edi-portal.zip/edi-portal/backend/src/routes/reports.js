'use strict';

const { Router } = require('express');
const { v4: uuidv4 } = require('uuid');

const auth       = require('../middleware/auth');
const dynamoSvc  = require('../services/dynamodb');
const s3Svc      = require('../services/s3');
const sesSvc     = require('../services/ses');
const { generate270CSV, generate271CSV, generatePaymentSummaryCSV } = require('../utils/csvGenerator');
const { generateReferenceId } = require('../utils/referenceId');
const { TABLES, REPORT_TYPES } = require('../config/constants');

const router = Router();
router.use(auth);

// ── POST /api/reports/generate — Generate and store a report ─────────────
router.post('/generate', async (req, res, next) => {
  try {
    const { reportType, dateFrom, dateTo } = req.body;

    if (!reportType || !Object.values(REPORT_TYPES).includes(reportType)) {
      return res.status(400).json({
        success: false,
        message: `Invalid report type. Valid types: ${Object.values(REPORT_TYPES).join(', ')}`,
      });
    }

    let csvContent = '';
    let filename = '';

    if (reportType === REPORT_TYPES.EDI_270 || reportType === REPORT_TYPES.EDI_271) {
      const { items } = await dynamoSvc.queryItems(
        TABLES.TRANSACTIONS,
        'userId = :uid',
        {
          expressionAttributeValues: { ':uid': req.user.sub },
          scanIndexForward: false,
          limit: 500,
        },
      );

      const filtered = items.filter((t) => {
        if (t.transactionType !== '270') return false;
        if (dateFrom && t.createdAt < dateFrom) return false;
        if (dateTo   && t.createdAt > dateTo)   return false;
        return true;
      });

      csvContent = reportType === REPORT_TYPES.EDI_270
        ? generate270CSV(filtered)
        : generate271CSV(filtered.filter((t) => t.status === 'RESPONSE_RECEIVED'));

      filename = `clearpath-${reportType}-${new Date().toISOString().slice(0, 10)}.csv`;
    } else if (reportType === REPORT_TYPES.PAYMENT_SUMMARY) {
      const { items } = await dynamoSvc.queryItems(
        TABLES.PAYMENTS,
        'userId = :uid',
        {
          expressionAttributeValues: { ':uid': req.user.sub },
          scanIndexForward: false,
          limit: 500,
        },
      );

      const filtered = items.filter((p) => {
        if (dateFrom && p.createdAt < dateFrom) return false;
        if (dateTo   && p.createdAt > dateTo)   return false;
        return true;
      });

      csvContent = generatePaymentSummaryCSV(filtered);
      filename = `clearpath-payments-${new Date().toISOString().slice(0, 10)}.csv`;
    }

    if (!csvContent) {
      return res.status(404).json({ success: false, message: 'No data found for the selected date range.' });
    }

    const reportId = uuidv4();
    const referenceId = generateReferenceId();
    const s3Key = `reports/${req.user.sub}/${referenceId}.csv`;

    // Upload to S3
    try {
      await s3Svc.uploadFile({
        bucket: process.env.S3_BUCKET,
        key: s3Key,
        body: csvContent,
        contentType: 'text/csv',
      });
    } catch (s3Err) {
      console.warn('[reports] S3 upload failed:', s3Err.message);
    }

    // Record in DynamoDB
    const report = {
      userId: req.user.sub,
      reportId,
      referenceId,
      reportType,
      filename,
      s3Key,
      dateFrom: dateFrom || '',
      dateTo: dateTo || '',
      rowCount: csvContent.split('\n').length - 1,
      status: 'READY',
    };
    await dynamoSvc.putItem(TABLES.REPORTS, report);

    // Notify via email
    try {
      await sesSvc.sendReportReadyEmail({
        to: req.user.email,
        reportType,
        referenceId,
        filename,
      });
    } catch (emailErr) {
      console.warn('[reports] Notification email failed:', emailErr.message);
    }

    res.status(201).json({ success: true, report, referenceId });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/reports — List reports ──────────────────────────────────────
router.get('/', async (req, res, next) => {
  try {
    const { items } = await dynamoSvc.queryItems(
      TABLES.REPORTS,
      'userId = :uid',
      {
        expressionAttributeValues: { ':uid': req.user.sub },
        scanIndexForward: false,
        limit: 50,
      },
    );
    res.json({ success: true, reports: items });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/reports/:id/download — Download report ──────────────────────
router.get('/:id/download', async (req, res, next) => {
  try {
    const report = await dynamoSvc.getItem(TABLES.REPORTS, {
      userId: req.user.sub,
      reportId: req.params.id,
    });
    if (!report) return res.status(404).json({ success: false, message: 'Report not found.' });

    const url = await s3Svc.getSignedDownloadUrl({
      bucket: process.env.S3_BUCKET,
      key: report.s3Key,
      expiresIn: 300,
      filename: report.filename,
    });

    res.json({ success: true, url, filename: report.filename });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/reports/:id/inline — Serve CSV inline (for direct browser download) ─
router.get('/:id/inline', async (req, res, next) => {
  try {
    const report = await dynamoSvc.getItem(TABLES.REPORTS, {
      userId: req.user.sub,
      reportId: req.params.id,
    });
    if (!report) return res.status(404).json({ success: false, message: 'Report not found.' });

    const file = await s3Svc.getFile({
      bucket: process.env.S3_BUCKET,
      key: report.s3Key,
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${report.filename}"`);
    res.send(file);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
