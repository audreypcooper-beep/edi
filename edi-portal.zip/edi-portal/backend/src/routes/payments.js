'use strict';

const { Router } = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');

const auth       = require('../middleware/auth');
const dynamoSvc  = require('../services/dynamodb');
const sesSvc     = require('../services/ses');
const { generateReferenceId } = require('../utils/referenceId');
const { TABLES, PAYMENT_STATUS } = require('../config/constants');

const router = Router();
router.use(auth);

function validateReq(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({ success: false, message: errors.array()[0].msg, errors: errors.array() });
    return false;
  }
  return true;
}

// ── POST /api/payments — Submit a payment ────────────────────────────────
router.post(
  '/',
  [
    body('amount').isFloat({ gt: 0 }).withMessage('Amount must be a positive number'),
    body('paymentType').isIn(['ACH', 'WIRE', 'CHECK', 'CARD']).withMessage('Invalid payment type'),
    body('accountId').notEmpty().withMessage('Bank account ID required'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const { amount, paymentType, accountId, description } = req.body;

      // Look up bank account to validate ownership
      const account = await dynamoSvc.getItem(TABLES.BANK_ACCOUNTS, {
        userId: req.user.sub,
        accountId,
      });
      if (!account) {
        return res.status(404).json({ success: false, message: 'Bank account not found.' });
      }

      const paymentId = uuidv4();
      const referenceId = generateReferenceId();

      const payment = {
        userId: req.user.sub,
        paymentId,
        referenceId,
        amount: parseFloat(amount),
        paymentType,
        accountId,
        accountType: account.accountType,
        description: description || '',
        status: PAYMENT_STATUS.PENDING,
        paymentDate: new Date().toISOString().slice(0, 10),
      };

      await dynamoSvc.putItem(TABLES.PAYMENTS, payment);

      // Send confirmation email
      try {
        await sesSvc.sendPaymentConfirmationEmail({
          to: req.user.email,
          referenceId,
          amount: parseFloat(amount).toFixed(2),
          paymentType,
          accountLast4: account.accountNumberMasked || '****',
        });
      } catch (emailErr) {
        console.warn('[payments] Confirmation email failed:', emailErr.message);
      }

      res.status(201).json({ success: true, payment });
    } catch (err) {
      next(err);
    }
  },
);

// ── GET /api/payments — List payments ────────────────────────────────────
router.get('/', async (req, res, next) => {
  try {
    const { limit = '50' } = req.query;
    const { items } = await dynamoSvc.queryItems(
      TABLES.PAYMENTS,
      'userId = :uid',
      {
        expressionAttributeValues: { ':uid': req.user.sub },
        scanIndexForward: false,
        limit: Math.min(parseInt(limit, 10) || 50, 200),
      },
    );
    res.json({ success: true, payments: items });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/payments/:id — Get single payment ───────────────────────────
router.get('/:id', async (req, res, next) => {
  try {
    const payment = await dynamoSvc.getItem(TABLES.PAYMENTS, {
      userId: req.user.sub,
      paymentId: req.params.id,
    });
    if (!payment) return res.status(404).json({ success: false, message: 'Payment not found.' });
    res.json({ success: true, payment });
  } catch (err) {
    next(err);
  }
});

// ── POST /api/payments/bank-accounts — Add bank account ──────────────────
router.post(
  '/bank-accounts',
  [
    body('routingNumber').matches(/^\d{9}$/).withMessage('Routing number must be 9 digits'),
    body('accountNumber').notEmpty().withMessage('Account number required'),
    body('accountType').isIn(['CHECKING', 'SAVINGS']).withMessage('Account type must be CHECKING or SAVINGS'),
    body('bankName').notEmpty().withMessage('Bank name required'),
  ],
  async (req, res, next) => {
    try {
      if (!validateReq(req, res)) return;
      const { routingNumber, accountNumber, accountType, bankName, accountHolder } = req.body;

      const accountId = uuidv4();
      // Store masked account number only — never store full account number in plaintext
      const accountNumberMasked = '****' + accountNumber.slice(-4);

      const account = {
        userId: req.user.sub,
        accountId,
        routingNumber,
        accountNumberMasked,
        accountType,
        bankName,
        accountHolder: accountHolder || `${req.user.given_name} ${req.user.family_name}`.trim(),
        isDefault: false,
        status: 'ACTIVE',
      };

      await dynamoSvc.putItem(TABLES.BANK_ACCOUNTS, account);
      res.status(201).json({ success: true, account });
    } catch (err) {
      next(err);
    }
  },
);

// ── GET /api/payments/bank-accounts — List bank accounts ─────────────────
router.get('/bank-accounts', async (req, res, next) => {
  try {
    const { items } = await dynamoSvc.queryItems(
      TABLES.BANK_ACCOUNTS,
      'userId = :uid',
      { expressionAttributeValues: { ':uid': req.user.sub } },
    );
    res.json({ success: true, accounts: items });
  } catch (err) {
    next(err);
  }
});

// ── DELETE /api/payments/bank-accounts/:id — Remove account ──────────────
router.delete('/bank-accounts/:id', async (req, res, next) => {
  try {
    const account = await dynamoSvc.getItem(TABLES.BANK_ACCOUNTS, {
      userId: req.user.sub,
      accountId: req.params.id,
    });
    if (!account) return res.status(404).json({ success: false, message: 'Account not found.' });
    await dynamoSvc.deleteItem(TABLES.BANK_ACCOUNTS, {
      userId: req.user.sub,
      accountId: req.params.id,
    });
    res.json({ success: true, message: 'Account removed.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
